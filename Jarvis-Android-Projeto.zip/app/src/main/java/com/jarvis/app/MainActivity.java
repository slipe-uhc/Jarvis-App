package com.jarvis.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Vibrator;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends Activity {
    private WebView web;
    private SpeechRecognizer recognizer;
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setBackgroundColor(0xFF040812);
        web.addJavascriptInterface(new Bridge(), "AndroidJarvis");
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String u = r.getUrl().toString();
                if (u.startsWith("file:")) return false;
                openExternal(u);
                return true;
            }
        });
        web.loadUrl("file:///android_asset/index.html");
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    private void js(final String code) {
        ui.post(new Runnable() {
            @Override
            public void run() {
                if (web != null) web.evaluateJavascript(code, null);
            }
        });
    }

    private void openExternal(String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            // nenhum app para abrir
        }
    }

    static PendingIntent alarmIntent(Context c, int id, String title, String text) {
        Intent i = new Intent(c, AlarmReceiver.class);
        i.putExtra("title", title);
        i.putExtra("text", text);
        return PendingIntent.getBroadcast(c, id, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private void startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 2);
            js("window.__jarvisEnd && window.__jarvisEnd('perm')");
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            js("window.__jarvisEnd && window.__jarvisEnd('indisponivel')");
            return;
        }
        if (recognizer != null) {
            recognizer.destroy();
            recognizer = null;
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle p) { }
            @Override public void onBeginningOfSpeech() { }
            @Override public void onRmsChanged(float v) { }
            @Override public void onBufferReceived(byte[] b) { }
            @Override public void onEndOfSpeech() { }
            @Override public void onPartialResults(Bundle p) { }
            @Override public void onEvent(int t, Bundle p) { }

            @Override
            public void onError(int err) {
                boolean quiet = err == SpeechRecognizer.ERROR_NO_MATCH || err == SpeechRecognizer.ERROR_SPEECH_TIMEOUT;
                js("window.__jarvisEnd && window.__jarvisEnd(" + (quiet ? "''" : "'erro'") + ")");
            }

            @Override
            public void onResults(Bundle results) {
                ArrayList<String> list = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (list != null && !list.isEmpty()) {
                    js("window.__jarvisHeard && window.__jarvisHeard(" + JSONObject.quote(list.get(0)) + ")");
                }
                js("window.__jarvisEnd && window.__jarvisEnd('')");
            }
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR");
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        recognizer.startListening(i);
    }

    private void stopListening() {
        if (recognizer != null) {
            recognizer.destroy();
            recognizer = null;
        }
    }

    public class Bridge {
        @JavascriptInterface
        public String platform() { return "android"; }

        @JavascriptInterface
        public void open(final String url) {
            ui.post(new Runnable() { @Override public void run() { openExternal(url); } });
        }

        @JavascriptInterface
        public void listen() {
            ui.post(new Runnable() { @Override public void run() { startListening(); } });
        }

        @JavascriptInterface
        public void stopListen() {
            ui.post(new Runnable() { @Override public void run() { stopListening(); } });
        }

        @JavascriptInterface
        public void vibrate(int ms) {
            Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (v != null) v.vibrate(ms);
        }

        @JavascriptInterface
        public void schedule(String json) {
            try {
                Context c = MainActivity.this;
                SharedPreferences p = c.getSharedPreferences("jarvis", MODE_PRIVATE);
                AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
                String old = p.getString("ids", "");
                if (!old.isEmpty()) {
                    for (String x : old.split(",")) {
                        if (!x.isEmpty()) am.cancel(alarmIntent(c, Integer.parseInt(x), "", ""));
                    }
                }
                JSONArray a = new JSONArray(json);
                StringBuilder ids = new StringBuilder();
                long now = System.currentTimeMillis();
                for (int k = 0; k < a.length(); k++) {
                    JSONObject o = a.getJSONObject(k);
                    int id = o.getInt("id");
                    long at = o.getLong("at");
                    if (at <= now) continue;
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, alarmIntent(c, id, o.getString("title"), o.getString("text")));
                    ids.append(id).append(",");
                }
                p.edit().putString("ids", ids.toString()).apply();
            } catch (Exception e) {
                // agenda inválida: ignora
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        js("window.__jarvisVis && window.__jarvisVis(true)");
    }

    @Override
    protected void onResume() {
        super.onResume();
        js("window.__jarvisVis && window.__jarvisVis(false)");
    }

    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }

    @Override
    protected void onDestroy() {
        stopListening();
        if (web != null) {
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
